# Browser Manager

Browser Manager 模块负责管理浏览器实例的生命周期、异常巡检以及自动化的交互处理。它提供了一个高层次的抽象，集成了反爬虫、多 Event Loop 兼容以及异常自动恢复功能。

---

## 📁 模块结构

- `engine.py`: 核心浏览器引擎，管理 `Browser` 实例和 `Context` 隔离。
- `guard.py`: 页面巡检员 (`PageGuard`)，监听页面事件并自动触发异常处理。
- `registry.py`: 处理器注册表，管理各种异常处理器（如登录、验证码）。
- `handlers/`: 存放具体的异常处理器实现。
  - `base.py`: 处理器基类。
  - `login_handler.py`: 登录异常处理。

---

## 🚀 核心组件

### 1. Browser Engine (`engine.py`)
负责 Playwright 浏览器的启动与维护。
- **单例/重用**: 自动维护全局唯一的 `Browser` 实例。
- **反爬集成**: 内置 `playwright-stealth` 支持。
- **鲁棒性**: 自动检测 Event Loop 变更并重启浏览器，处理断连恢复。

### 2. Page Guard (`guard.py`)
自动化的页面状态监控器。
- **事件驱动**: 挂载到 `Page` 的 `framenavigated` 事件。
- **优先级调度**: 根据注册的处理器优先级，按顺序检测异常。
- **非阻塞**: 使用异步锁确保同一时间只有一个巡检任务在运行。

### 3. Handler Registry (`registry.py`)
处理器的中央管理器。
- **动态控制**: 支持在运行时启用或禁用特定的处理器。
- **排序**: 确保巡检时按 `priority` 顺序执行检测。

---

## 🛠️ 使用示例

```python
from common.browser_manager.engine import BrowserEngine
from common.browser_manager.guard import PageGuard

# 1. 初始化引擎
engine = BrowserEngine(headless=False)

# 2. 获取页面
async with engine.create_context() as context:
    page = await context.new_page()
    
    # 3. 挂载巡检员
    guard = PageGuard()
    guard.attach_to_page(page)
    
    # 4. 正常操作，异常（如遇到登录墙）将由 guard 自动处理
    await page.goto("https://target-site.com")
```
