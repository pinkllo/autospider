# Crawler 模块

Crawler 模块是 AutoSpider 的核心爬取引擎，负责执行批量网页数据采集任务。该模块集成了 URL 收集、批量爬取、断点续传、速率控制等关键功能，支持从列表页自动发现并导航到详情页，实现全流程自动化的数据采集。

---

## 模块结构

```
crawler/
├── __init__.py          # 模块入口，导出 BatchCollector 和 URLCollector
├── url_collector.py     # URL 收集器，负责从列表页发现详情页 URL
├── batch_collector.py   # 批量爬取控制器，协调整个爬取流程
└── checkpoint/          # 断点续传系统
    ├── __init__.py      # 检查点模块导出
    ├── rate_controller.py   # 自适应速率控制器
    └── resume_strategy.py   # 断点恢复策略
```

---

## 📑 函数目录

### 🔍 URL 收集器 (url_collector.py)
- `URLCollector` - URL 收集器主类
- `run()` - 执行 URL 收集任务
- `explore()` - 探索阶段，访问详情页样本
- `collect()` - 收集阶段，批量收集 URL
- `analyze()` - 分析阶段，提取公共 XPath 模式

### 📦 批量爬取控制器 (batch_collector.py)
- `BatchCollector` - 批量爬取控制器主类
- `collect_from_config()` - 从配置文件加载并执行爬取
- `collect()` - 执行批量爬取任务
- `save_progress()` - 保存爬取进度
- `load_progress()` - 加载爬取进度

### ⚡ 自适应速率控制器 (rate_controller.py)
- `AdaptiveRateController` - 速率控制器主类
- `get_delay()` - 获取当前延迟时间
- `apply_penalty()` - 应用惩罚（遇到反爬时）
- `record_success()` - 记录成功请求
- `set_level(level)` - 设置降速等级
- `reset()` - 重置控制器状态

### 🔄 断点恢复策略 (resume_strategy.py)
- `ResumeStrategy` - 恢复策略基类
- `URLPatternStrategy` - URL 规律爆破策略
- `WidgetJumpStrategy` - 控件直达策略
- `SmartSkipStrategy` - 智能跳过策略
- `ResumeCoordinator` - 恢复策略协调器

---

## 🚀 核心功能

### URLCollector

URLCollector 是负责从列表页收集详情页 URL 的专用组件。它通过多阶段探索策略，自动发现并导航到目标详情页，同时进行 URL 去重和持久化存储。

```python
from autospider import URLCollector

collector = URLCollector(
    list_url="https://example.com/products",
    task_description="采集商品详情页",
    explore_count=5,
    common_detail_xpath=None,
    redis_manager=None
)

result = await collector.run()
print(f"收集到 {len(result.detail_urls)} 个详情页 URL")
```

### BatchCollector

BatchCollector 是批量爬取的主控制器，负责协调整个采集流程的各个环节。

```python
from autospider import BatchCollector

collector = BatchCollector(
    config_path="./config.yaml",
    redis_manager=redis_manager
)

result = await collector.collect_from_config()
```

### AdaptiveRateController

AdaptiveRateController 实现了自适应速率控制算法，能够根据网站的反爬策略自动调整请求频率。

```python
from autospider.checkpoint import AdaptiveRateController

controller = AdaptiveRateController(
    base_delay=1.0,      # 基础延迟 1 秒
    backoff_factor=1.5,  # 退避因子 1.5
    max_level=5,         # 最大降速等级 5
    credit_recovery_pages=10,  # 每 10 个成功请求恢复一级
    initial_level=0      # 初始等级 0
)

# 获取当前延迟
delay = controller.get_delay()

# 触发惩罚（遇到反爬）
controller.apply_penalty()

# 记录成功
controller.record_success()

# 从检查点恢复
controller.set_level(3)
```

### ResumeStrategy

ResumeStrategy 定义了断点恢复的策略接口，目前提供了三种具体的恢复策略实现。

```python
from autospider.checkpoint import (
    ResumeCoordinator,
    URLPatternStrategy,
    WidgetJumpStrategy,
    SmartSkipStrategy
)

# 使用 URL 规律爆破策略
strategy = URLPatternStrategy(list_url="https://example.com/list?page=1")

# 使用控件直达策略
widget_strategy = WidgetJumpStrategy(
    jump_widget_xpath={
        "input": "input.page-input",
        "button": "button.go-btn"
    }
)

# 使用智能跳过策略
smart_strategy = SmartSkipStrategy(
    list_url="https://example.com/list",
    item_xpath="//div[@class='product-item']",
    nav_steps=[...]
)

# 协调器自动选择最佳策略
coordinator = ResumeCoordinator([strategy, widget_strategy, smart_strategy])
result = await coordinator.try_resume(page, target_page=50)
```

---

## 💡 特性说明

### 速率控制算法

基于指数退避策略的智能速率控制：

```python
# 延迟计算公式
current_delay = base_delay * (backoff_factor ^ current_level)

# 惩罚机制
- 每次触发惩罚，current_level 增加1
- 延迟时间按指数增长
- 避免短时间内频繁触发惩罚

# 恢复机制
- 每成功处理 credit_recovery_pages 个页面，current_level 减少1
- 逐步恢复正常速率
- 防止快速波动
```

### 恢复策略选择

系统自动选择最适合的恢复策略：

1. **URLPatternStrategy**：适用于 URL 包含页码参数的网站
   - 直接构造目标页 URL
   - 快速跳转，效率最高
   - 需要 URL 规律明显

2. **WidgetJumpStrategy**：适用于使用页码输入控件的网站
   - 模拟输入页码并点击确定
   - 适用于现代 Web 应用
   - 需要控件定位准确

3. **SmartSkipStrategy**：兜底方案，通用性最强
   - 从第一页开始快速检测
   - 检测到新数据时回退一页
   - 确保数据完整性

### 状态持久化

支持控制器状态的保存和恢复：

```python
# 保存当前状态
state = controller.get_state()
await storage.save_data("rate_controller_state", state)

# 恢复状态
saved_state = await storage.load_data("rate_controller_state")
if saved_state:
    controller.restore_state(saved_state)
    print("速率控制器状态已恢复")
```

---

## 🔧 使用示例

### 完整的爬取任务管理

```python
import asyncio
from autospider.checkpoint.rate_controller import AdaptiveRateController
from autospider.checkpoint.resume_strategy import ResumeCoordinator
from autospider.common.storage.redis_manager import RedisManager

class CrawlTaskManager:
    """爬取任务管理器"""

    def __init__(self, task_id, list_url, storage_manager):
        self.task_id = task_id
        self.list_url = list_url
        self.storage = storage_manager

        # 创建速率控制器
        self.rate_controller = AdaptiveRateController(
            base_delay=1.0,
            backoff_factor=1.5,
            max_level=5,
            credit_recovery_pages=10
        )

        # 创建恢复策略协调器
        self.resume_coordinator = ResumeCoordinator.create_default(list_url)

    async def load_progress(self):
        """加载任务进度"""
        progress_key = f"task:{self.task_id}:progress"
        progress = await self.storage.get_metadata(progress_key)

        if progress:
            # 恢复速率控制器状态
            if 'rate_controller_state' in progress:
                self.rate_controller.restore_state(progress['rate_controller_state'])

            return progress['current_page'], progress['collected_urls']

        return 1, []  # 从头开始

    async def save_progress(self, current_page, collected_urls):
        """保存任务进度"""
        progress_key = f"task:{self.task_id}:progress"

        progress_data = {
            'current_page': current_page,
            'collected_urls': collected_urls,
            'rate_controller_state': self.rate_controller.get_state(),
            'last_saved': '2026-01-08T10:00:00Z'
        }

        await self.storage.save_item(progress_key, progress_data)

    async def crawl_page(self, page_num):
        """爬取单个页面"""
        # 获取当前延迟
        delay = self.rate_controller.get_delay()
        print(f"爬取第{page_num}页，延迟: {delay:.2f}秒")

        # 等待延迟时间
        await asyncio.sleep(delay)

        try:
            # 模拟页面爬取（这里应该是实际的爬取逻辑）
            if page_num % 7 == 0:  # 模拟偶尔遇到反爬
                print(f"第{page_num}页遇到反爬机制")
                self.rate_controller.apply_penalty()
                raise Exception("Anti-crawler detected")

            # 模拟成功爬取
            urls = [f"https://example.com/product/{page_num * 10 + i}"
                   for i in range(10)]

            self.rate_controller.record_success()
            return urls

        except Exception as e:
            print(f"爬取第{page_num}页失败: {e}")
            return []

    async def resume_to_page(self, current_page, target_page):
        """恢复到指定页面"""
        print(f"尝试从第{current_page}页恢复到第{target_page}页")

        result = await self.resume_coordinator.try_resume(current_page, target_page)

        if result.success:
            print(f"成功恢复到第{result.resumed_page}页")
            return result.resumed_page
        else:
            print("恢复失败，从头开始")
            return 1

    async def run(self, max_pages=100):
        """运行爬取任务"""
        # 加载进度
        current_page, collected_urls = await self.load_progress()

        print(f"开始爬取，当前进度: 第{current_page}页")

        while current_page <= max_pages:
            # 爬取当前页面
            new_urls = await self.crawl_page(current_page)
            collected_urls.extend(new_urls)

            # 每5页保存一次进度
            if current_page % 5 == 0:
                await self.save_progress(current_page, collected_urls)
                print(f"进度已保存: 第{current_page}页，URL数量: {len(collected_urls)}")

            current_page += 1

        # 任务完成，清理进度数据
        await self.storage.mark_as_deleted(f"task:{self.task_id}:progress")
        print(f"任务完成! 共收集 {len(collected_urls)} 个URL")

        return collected_urls

# 使用示例
async def main():
    # 创建存储管理器
    storage = RedisManager(key_prefix="crawler:")
    await storage.connect()

    try:
        # 创建任务管理器
        task_manager = CrawlTaskManager(
            task_id="demo_task",
            list_url="https://example.com/products?page=1",
            storage_manager=storage
        )

        # 运行爬取任务
        urls = await task_manager.run(max_pages=20)

        print(f"最终收集的URL数量: {len(urls)}")

    finally:
        await storage.disconnect()

asyncio.run(main())
```

---

## 📝 最佳实践

### 速率控制配置

1. **基础延迟**：根据目标网站响应时间设置
2. **退避因子**：1.3-2.0之间，避免过于激进
3. **最大等级**：3-5级，避免延迟过长
4. **恢复阈值**：8-15个成功请求恢复一级

### 恢复策略选择

1. **优先URL模式**：URL规律明显时效率最高
2. **次选控件跳转**：现代Web应用适用
3. **兜底智能跳过**：通用性强但效率较低
4. **混合策略**：根据实际情况组合使用

### 状态管理

1. **定期保存**：每爬取一定数量页面后保存状态
2. **异常处理**：捕获异常并保存当前状态
3. **状态验证**：恢复时验证状态完整性
4. **清理机制**：任务完成后清理状态数据

---

## 🔍 故障排除

### 常见问题

1. **速率控制过于保守**
   - 调整基础延迟和退避因子
   - 增加恢复阈值
   - 考虑网站的实际反爬强度

2. **恢复策略失败**
   - 检查 URL 模式是否正确
   - 验证控件定位准确性
   - 考虑使用兜底策略

3. **状态恢复异常**
   - 检查状态数据完整性
   - 验证序列化/反序列化过程
   - 确认存储后端正常工作

### 调试技巧

```python
# 启用详细日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 监控速率控制器状态
print(f"当前等级: {controller.current_level}")
print(f"成功计数: {controller.success_count}")
print(f"信用值: {controller.credit}")

# 测试恢复策略
for strategy in coordinator.strategies:
    print(f"策略 {strategy.__class__.__name__}: {strategy.description}")

# 性能监控
import time
start_time = time.time()
# 执行操作
end_time = time.time()
print(f"操作耗时: {end_time - start_time:.3f}秒")
```

---

*最后更新: 2026-01-08*
